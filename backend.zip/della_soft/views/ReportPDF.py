from fpdf import FPDF

def generate_stock_rotation_pdf(data):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Reporte de Stock Disponible vs Rotación", 0, 1, "C")
    pdf.ln(10)
    pdf.set_font("Arial", size=12)
    pdf.cell(60, 8, "Producto", 1)
    pdf.cell(40, 8, "Stock", 1)
    pdf.cell(60, 8, "Rotación (Vendido)", 1)
    pdf.ln()
    for item in data:
        pdf.cell(60, 8, str(item["producto"]), 1)
        pdf.cell(40, 8, str(item["stock"]), 1)
        pdf.cell(60, 8, str(item["rotacion"]), 1)
        pdf.ln()
    output_path = "stock_rotation_report.pdf"
    pdf.output(output_path)
    return output_path

def generate_top_products_pdf(data):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Top 5 Productos Más Vendidos (Mes)", 0, 1, "C")
    pdf.ln(10)
    pdf.set_font("Arial", size=12)
    pdf.cell(80, 8, "Producto", 1)
    pdf.cell(40, 8, "Cantidad Vendida", 1)
    pdf.ln()
    for item in data:
        pdf.cell(80, 8, str(item["producto"]), 1)
        pdf.cell(40, 8, str(item["cantidad"]), 1)
        pdf.ln()
    output_path = "top_products_report.pdf"
    pdf.output(output_path)
    return output_path

def generate_orders_per_day_pdf(data):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 16)
    pdf.cell(0, 10, "Cantidad de Pedidos por Día (Mes)", 0, 1, "C")
    pdf.ln(10)
    pdf.set_font("Arial", size=12)
    pdf.cell(40, 8, "Fecha", 1)
    pdf.cell(40, 8, "Pedidos", 1)
    pdf.ln()
    for item in data:
        pdf.cell(40, 8, str(item["fecha"]), 1)
        pdf.cell(40, 8, str(item["pedidos"]), 1)
        pdf.ln()
    output_path = "orders_per_day_report.pdf"
    pdf.output(output_path)
    return output_path
