import reflex as rx

class TestState(rx.State):
    pass

def DashboardView():
    test_data = [
        {"producto": "A", "stock": 10, "rotacion": 4},
        {"producto": "B", "stock": 5, "rotacion": 2},
        {"producto": "C", "stock": 8, "rotacion": 9}
    ]
    return rx.box(
        rx.heading("PRUEBA GRAFICO", size="5", color="#3E2723"),
        rx.recharts.BarChart(
            data=test_data,
            children=[
                rx.recharts.XAxis(dataKey="producto"),
                rx.recharts.YAxis(),
                rx.recharts.Bar(dataKey="stock", name="Stock"),
                rx.recharts.Bar(dataKey="rotacion", name="Rotación"),
            ],
            height=300,
            width=500,
        ),
    )
