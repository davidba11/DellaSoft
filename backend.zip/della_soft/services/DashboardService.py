from ..repositories.ProductRepository import select_all as select_all_products
from ..repositories.ProductOrderRepository import select_all as select_all_product_orders
from ..repositories.OrderRepository import select_all as select_all_orders
from datetime import date, timedelta

async def get_stock_rotation_data_month():
    productos = select_all_products()           # Síncrono (si tus modelos lo son)
    product_orders = select_all_product_orders()# Síncrono
    orders = await select_all_orders()          # ASYNC

    mes_actual = date.today().month
    año_actual = date.today().year

    data = []
    for producto in productos:
        stock = getattr(producto, 'stock', 0)
        cantidad_vendida = sum([
            po.quantity for po in product_orders
            if po.id_product == producto.id and
                any(
                    o.id == po.id_order and
                    o.order_date.month == mes_actual and
                    o.order_date.year == año_actual
                    for o in orders
                )
        ])
        data.append({
            "Producto": producto.name,
            "Stock Disponible": stock,
            "Cantidad Vendida (Rotación)": cantidad_vendida
        })
    return data

async def get_top_products_month():
    productos = select_all_products()
    product_orders = select_all_product_orders()
    orders = await select_all_orders()

    mes_actual = date.today().month
    año_actual = date.today().year

    ventas = []
    for producto in productos:
        cantidad_vendida = sum([
            po.quantity for po in product_orders
            if po.id_product == producto.id and
                any(
                    o.id == po.id_order and
                    o.order_date.month == mes_actual and
                    o.order_date.year == año_actual
                    for o in orders
                )
        ])
        ventas.append({
            "Producto": producto.name,
            "Cantidad Vendida": cantidad_vendida
        })
    ventas.sort(key=lambda x: x["Cantidad Vendida"], reverse=True)
    return ventas[:5]

async def get_orders_per_day_month():
    orders = await select_all_orders()
    mes_actual = date.today().month
    año_actual = date.today().year

    today = date.today()
    primer_dia = today.replace(day=1)
    if mes_actual == 12:
        primer_dia_siguiente_mes = primer_dia.replace(year=año_actual+1, month=1)
    else:
        primer_dia_siguiente_mes = primer_dia.replace(month=mes_actual+1)
    dias = (primer_dia_siguiente_mes - primer_dia).days

    conteo = { (primer_dia + timedelta(days=i)).strftime("%d/%m") : 0 for i in range(dias) }

    for order in orders:
        if order.order_date.month == mes_actual and order.order_date.year == año_actual:
            clave = order.order_date.strftime("%d/%m")
            if clave in conteo:
                conteo[clave] += 1

    return [{"Fecha": k, "Pedidos": v} for k, v in sorted(conteo.items())]
