import reflex as rx

config = rx.Config(
    app_name="della_soft",
    db_url="postgresql://postgres:admin@localhost:5432/DellaSoft",
)